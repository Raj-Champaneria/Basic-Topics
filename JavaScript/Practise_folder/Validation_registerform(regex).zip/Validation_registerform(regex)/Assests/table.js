let table = document.createElement("table");
table.classList.add("table")
let headers = [
  { header: "First Name", key: "fname" },
  { header: "Last Name", key: "lname" },
  { header: "Email", key: "email" },
  { header: "Contact", key: "contact" },
  { header: "Salary", key: "salary" },
];
function thead(t) {
  let thead = table.createTHead("thead");
  table.appendChild(thead);

  for (const iterator of headers) {
    let th=document.createElement("th");
    thead.appendChild(th);
    th.classList.add("table-th");
    let text=document.createTextNode(iterator.header);
    th.appendChild(text);
  }
}
thead(table);

function tbody(){
    // tbody.innerHTML=" "
    let tbody=table.createTBody("tbody");
    table.appendChild(tbody);
    
    fetch("http://localhost:3000/validation")
    .then(res=>res.json())
    .then(data=>{
        for (const element of data) {
            let tr=document.createElement("tr");
            tbody.appendChild(tr)
            for (const iterator of headers) {
               let td=document.createElement("td");
               tr.appendChild(td);
               let text=document.createTextNode(element[iterator["key"]]);
               td.appendChild(text)
            }
        }
    })
    // .catch(error=>console.log("server not connected proper"))
   
}
tbody()

let container=document.querySelector(".container");
let div=document.createElement("div");
container.appendChild(div);
div.classList.add("div-wrapper");
div.appendChild(table);